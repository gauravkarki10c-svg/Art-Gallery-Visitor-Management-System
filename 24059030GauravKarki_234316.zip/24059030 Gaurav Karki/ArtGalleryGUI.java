import javax.swing.*;
import java.awt.*;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.*;
import java.awt.event.*; 
import javax.swing.table.*;
import java.io.*;
import java.util.Scanner;

// ArtGalleryGUI now extends JFrame to manage its own components
public class ArtGalleryGUI extends JFrame {
    // ArrayList to store ArtGalleryVisitor objects
    private static ArrayList<ArtGalleryVisitor> visitorList = new ArrayList<>();

    // GUI Components (declared as static to access in ActionListeners)
    private static JTextField visitorIdField;
    private static JTextField fullNameField;
    private static JTextField contactNumberField;
    private static JTextField ticketTypeField;
    private static JTextField artworkIdField;
    private static JTextField artworkNameField;
    private static JTextField artworkPriceField;
    private static JTextField cancellationReasonField;

    private static JRadioButton maleButton;
    private static JRadioButton femaleButton;
    private static JRadioButton othersButton;
    private static ButtonGroup buttonGrp;

    private static JComboBox<String> dayCombo;
    private static JComboBox<String> monthCombo;
    private static JComboBox<String> yearCombo;
    private static JComboBox<String> ticketType;

    private static void setButtonColor1(JButton button) {
        button.setBackground(new Color(137, 207, 240)); 
        button.setOpaque(true);
    }

    private static void setButtonColor2(JButton button) {
        button.setBackground(new Color(240, 128, 128)); 
        button.setOpaque(true);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("🖼ArtGalleryGUI🖼");
        JPanel panel = new JPanel();
        panel.setBounds(20,20, 950, 700);
        panel.setBackground(new Color(255, 239, 213));
        panel.setBorder(BorderFactory.createTitledBorder("Art Gallery Management System"));
        panel.setLayout(null);

        // Add Visitors Section
        JLabel visitorIdLabel = new JLabel("Visitor ID:");
        panel.add(visitorIdLabel);
        visitorIdLabel.setBounds(50, 40, 120, 25);

        visitorIdField = new JTextField();
        panel.add(visitorIdField);
        visitorIdField.setBounds(180, 40, 200, 25);

        JLabel fullNameLabel = new JLabel("Full Name:");
        panel.add(fullNameLabel);
        fullNameLabel.setBounds(50, 80, 120, 25);

        fullNameField = new JTextField();
        panel.add(fullNameField);
        fullNameField.setBounds(180, 80, 200, 25);

        JLabel gender = new JLabel("Gender:");
        panel.add(gender);
        gender.setBounds(50, 120, 120, 25);

        maleButton = new JRadioButton("Male");
        panel.add(maleButton);
        maleButton.setBounds(180, 120, 60, 25);

        femaleButton = new JRadioButton("Female");
        panel.add(femaleButton);
        femaleButton.setBounds(250, 120, 80, 25);

        othersButton = new JRadioButton("Others");
        panel.add(othersButton);
        othersButton.setBounds(340, 120, 80, 25);

        buttonGrp = new ButtonGroup();
        buttonGrp.add(maleButton);
        buttonGrp.add(femaleButton);
        buttonGrp.add(othersButton);

        JLabel registrationDate = new JLabel("Registration Date:");
        panel.add(registrationDate);
        registrationDate.setBounds(50, 160, 120, 25);

        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.valueOf(i + 1);
        }
        dayCombo = new JComboBox<>(days);
        panel.add(dayCombo);
        dayCombo.setBounds(180, 160, 60, 25);

        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        monthCombo = new JComboBox<>(months);
        panel.add(monthCombo);
        monthCombo.setBounds(250, 160, 80, 25);

        String[] years = new String[120];
        for (int i = 0; i < 120; i++) {
            years[i] = String.valueOf(1906 + i);
        }
        yearCombo = new JComboBox<>(years);
        panel.add(yearCombo);
        yearCombo.setBounds(340, 160, 80, 25);

        JLabel contactNumber = new JLabel("Contact Number:");
        panel.add(contactNumber);
        contactNumber.setBounds(50, 200, 120, 25);

        contactNumberField = new JTextField();
        panel.add(contactNumberField);
        contactNumberField.setBounds(180, 200, 200, 25);

        JLabel typeOfTicket = new JLabel("Ticket Type:");
        panel.add(typeOfTicket);
        typeOfTicket.setBounds(50, 240, 120, 25);

        String[] ticketTypes = {"Select", "Standard", "Elite"};
        ticketType = new JComboBox<>(ticketTypes);
        panel.add(ticketType);
        ticketType.setBounds(180, 240, 150, 25);

        JLabel ticketPrice = new JLabel("Ticket Price:");
        panel.add(ticketPrice);
        ticketPrice.setBounds(50, 280, 120, 25);

        ticketTypeField = new JTextField();
        ticketTypeField.setEditable(false);
        panel.add(ticketTypeField);
        ticketTypeField.setBounds(180, 280, 150, 25);

        // ActionListener for ticket type combo box to auto-fill price
        ticketType.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String selectedType = (String) ticketType.getSelectedItem();
                    if ("Standard".equals(selectedType)) {
                        ticketTypeField.setText("1000.0");
                    } else if ("Elite".equals(selectedType)) {
                        ticketTypeField.setText("2000.0");
                    } else {
                        ticketTypeField.setText("");
                    }
                }
            });

        // Right side buttons
        JButton addButton = new JButton("ADD");
        panel.add(addButton);
        addButton.setBounds(550, 40, 100, 35);

        JButton clearButton = new JButton("Clear");
        panel.add(clearButton);
        clearButton.setBounds(670, 40, 100, 35);

        JButton displayButton = new JButton("Display");
        panel.add(displayButton);
        displayButton.setBounds(790, 40, 100, 35);

        JButton readButton = new JButton("Read");
        panel.add(readButton);
        readButton.setBounds(550, 85, 100, 35);

        JButton saveButton = new JButton("Save");
        panel.add(saveButton);
        saveButton.setBounds(670, 85, 100, 35);

        // Purchase Section
        JLabel artworkId = new JLabel("Artwork ID:");
        panel.add(artworkId);
        artworkId.setBounds(50, 320, 120, 25);

        artworkIdField = new JTextField();
        panel.add(artworkIdField);
        artworkIdField.setBounds(180, 320, 150, 25);

        JLabel artworkName = new JLabel("Artwork Name:");
        panel.add(artworkName);
        artworkName.setBounds(380, 320, 120, 25);

        artworkNameField = new JTextField();
        panel.add(artworkNameField);
        artworkNameField.setBounds(510, 320, 180, 25);

        JLabel artworkPrice = new JLabel("Artwork Price:");
        panel.add(artworkPrice);
        artworkPrice.setBounds(50, 360, 120, 25);

        artworkPriceField = new JTextField();
        panel.add(artworkPriceField);
        artworkPriceField.setBounds(180, 360, 150, 25);

        JLabel cancellationReason = new JLabel("Cancellation Reason:");
        panel.add(cancellationReason);
        cancellationReason.setBounds(380, 360, 130, 25);

        cancellationReasonField = new JTextField();
        panel.add(cancellationReasonField);
        cancellationReasonField.setBounds(510, 360, 180, 25);

        JButton cancelButton = new JButton("Cancel");
        panel.add(cancelButton);
        cancelButton.setBounds(720, 360, 100, 35);

        JButton buyProductButton = new JButton("Buy Product");
        panel.add(buyProductButton);
        buyProductButton.setBounds(50, 420, 120, 35);

        JButton discountButton = new JButton("Discount");
        panel.add(discountButton);
        discountButton.setBounds(190, 420, 120, 35);

        JButton rewardButton = new JButton("Reward");
        panel.add(rewardButton);
        rewardButton.setBounds(330, 420, 120, 35);

        JButton generateBillButton = new JButton("Generate Bill");
        panel.add(generateBillButton);
        generateBillButton.setBounds(470, 420, 120, 35);

        // Manage visitors
        JButton logVisitorButton = new JButton("Log Visitor");
        panel.add(logVisitorButton);
        logVisitorButton.setBounds(50, 480, 140, 35);

        JButton assignPersonalAdvisorButton = new JButton("Assign Personal Advisor");
        panel.add(assignPersonalAdvisorButton);
        assignPersonalAdvisorButton.setBounds(210, 480, 180, 35);

        JButton isEligibleForDiscountUpgradeButton = new JButton("Check Upgrade");
        panel.add(isEligibleForDiscountUpgradeButton);
        isEligibleForDiscountUpgradeButton.setBounds(410, 480, 150, 35);

        setButtonColor1(addButton);
        setButtonColor1(clearButton);
        setButtonColor1(displayButton);
        setButtonColor1(readButton);
        setButtonColor1(saveButton);
        setButtonColor1(buyProductButton);
        setButtonColor1(discountButton);
        setButtonColor1(rewardButton);
        setButtonColor1(generateBillButton);
        setButtonColor1(logVisitorButton);
        setButtonColor1(assignPersonalAdvisorButton);
        setButtonColor1(isEligibleForDiscountUpgradeButton);

        setButtonColor2(cancelButton);

        // ADD BUTTON ACTION LISTENER
        addButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        // Get input values
                        String idText = visitorIdField.getText().trim();
                        String fullName = fullNameField.getText().trim();
                        String contactNumber = contactNumberField.getText().trim();

                        // Validate required fields
                        if (idText.isEmpty() || fullName.isEmpty() || contactNumber.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please fill all required fields (Visitor ID, Full Name, Contact Number)", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Parse and validate Visitor ID
                        int visitorId = Integer.parseInt(idText);

                        // Check for duplicate Visitor ID
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                JOptionPane.showMessageDialog(null, "Visitor ID already exists. Please use a unique ID.", 
                                    "Duplicate ID Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }

                        // Get gender
                        String gender = "";
                        if (maleButton.isSelected()) {
                            gender = "Male";
                        } else if (femaleButton.isSelected()) {
                            gender = "Female";
                        } else if (othersButton.isSelected()) {
                            gender = "Others";
                        } else {
                            JOptionPane.showMessageDialog(null, "Please select a gender", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Get registration date
                        String day = (String) dayCombo.getSelectedItem();
                        String month = (String) monthCombo.getSelectedItem();
                        String year = (String) yearCombo.getSelectedItem();
                        String registrationDate = day + "-" + month + "-" + year;

                        // Get ticket type and validate
                        String selectedTicketType = (String) ticketType.getSelectedItem();
                        if ("Select".equals(selectedTicketType)) {
                            JOptionPane.showMessageDialog(null, "Please select a ticket type", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Get ticket cost
                        double ticketCost = Double.parseDouble(ticketTypeField.getText());

                        // Create visitor object based on ticket type
                        ArtGalleryVisitor visitor = null;
                        if ("Standard".equals(selectedTicketType)) {
                            visitor = new StandardVisitor(visitorId, fullName, gender, contactNumber, 
                                registrationDate, ticketCost, selectedTicketType);
                        } else if ("Elite".equals(selectedTicketType)) {
                            visitor = new EliteVisitor(visitorId, fullName, gender, contactNumber, 
                                registrationDate, ticketCost, selectedTicketType);
                        }

                        // Add to ArrayList
                        visitorList.add(visitor);

                        JOptionPane.showMessageDialog(null, "Visitor added successfully!\nVisitor ID: " + visitorId + 
                            "\nName: " + fullName + "\nType: " + selectedTicketType, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter valid numeric values for Visitor ID", 
                            "Number Format Error", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An error occurred while adding visitor: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // CLEAR BUTTON ACTION LISTENER
        clearButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        // Clear all text fields
                        visitorIdField.setText("");
                        fullNameField.setText("");
                        contactNumberField.setText("");
                        ticketTypeField.setText("");
                        artworkIdField.setText("");
                        artworkNameField.setText("");
                        artworkPriceField.setText("");
                        cancellationReasonField.setText("");

                        // Clear radio button selections
                        buttonGrp.clearSelection();

                        // Clear combo boxes to default
                        dayCombo.setSelectedIndex(0);
                        monthCombo.setSelectedIndex(0);
                        yearCombo.setSelectedIndex(0);
                        ticketType.setSelectedIndex(0);

                        JOptionPane.showMessageDialog(null, "All fields cleared successfully!", 
                            "Clear Complete", JOptionPane.INFORMATION_MESSAGE);

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An error occurred while clearing fields: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // DISPLAY BUTTON ACTION LISTENER - Opens new window
        displayButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to display details", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId = Integer.parseInt(idText);
                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            // Create new window to display visitor details
                            showVisitorDetailsWindow(foundVisitor);
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                            "Number Format Error", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An error occurred while displaying visitor details: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // LOG VISITOR BUTTON ACTION LISTENER
        logVisitorButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to log visit", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId = Integer.parseInt(idText);
                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            foundVisitor.logVisit();
                            JOptionPane.showMessageDialog(null, 
                                "Visit logged successfully!\nVisitor ID: " + visitorId + 
                                "\nName: " + foundVisitor.getFullName() + 
                                "\nVisit Count: " + foundVisitor.getVisitCount() +
                                "\nStatus: Active", 
                                "Log Visit Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                            "Number Format Error", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An error occurred while logging visit: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // BUY PRODUCT BUTTON ACTION LISTENER
        buyProductButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();
                        String artworkIdText = artworkIdField.getText().trim();
                        String artworkName = artworkNameField.getText().trim();
                        String artworkPriceText = artworkPriceField.getText().trim();

                        // Validate required fields
                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (artworkIdText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter an Artwork ID", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (artworkName.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter an Artwork Name", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (artworkPriceText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter an Artwork Price", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Parse Visitor ID separately to give specific error message
                        int visitorId;
                        try {
                            visitorId = Integer.parseInt(idText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                                "Invalid Visitor ID", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Parse Artwork ID separately to give specific error message
                        int artworkId;
                        try {
                            artworkId = Integer.parseInt(artworkIdText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null,"Please enter valid numeric values for Artwork ID or Artwork Price", 
                                "Invalid Input", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Parse Artwork Price separately to give specific error message
                        double artworkPrice;
                        try {
                            artworkPrice = Double.parseDouble(artworkPriceText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null,"Please enter valid numeric values for Artwork ID or Artwork Price", 
                                "Invalid Input", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Validate artwork price is positive
                        if (artworkPrice <= 0) {
                            JOptionPane.showMessageDialog(null, "Artwork price must be greater than 0", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        // Validate artwork ID is positive
                        if (artworkId <= 0) {
                            JOptionPane.showMessageDialog(null, "Artwork ID must be greater than 0", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            String result = foundVisitor.buyProduct(artworkName, artworkPrice);
                            JOptionPane.showMessageDialog(null, result, 
                                "Purchase Result", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An unexpected error occurred: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // DISCOUNT BUTTON ACTION LISTENER
        discountButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to calculate discount", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId;
                        try {
                            visitorId = Integer.parseInt(idText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                                "Invalid Visitor ID", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            double discountAmount = foundVisitor.calculateDiscount();

                            if (discountAmount == 0.0) {
                                JOptionPane.showMessageDialog(null, 
                                    "No discount to calculate!\nReason: No product has been purchased yet.", 
                                    "Discount Calculation", JOptionPane.WARNING_MESSAGE);
                            } else {
                                String visitorType = foundVisitor instanceof StandardVisitor ? "Standard" : "Elite";
                                double finalPrice = foundVisitor.getFinalPrice();

                                JOptionPane.showMessageDialog(null, 
                                    "Discount Calculated Successfully!\n\n" +
                                    "Visitor ID: " + visitorId + "\n" +
                                    "Visitor Name: " + foundVisitor.getFullName() + "\n" +
                                    "Visitor Type: " + visitorType + "\n" +
                                    "Artwork: " + foundVisitor.getArtworkName() + "\n" +
                                    "Original Price: Rs. " + foundVisitor.getArtworkPrice() + "\n" +
                                    "Discount Amount: Rs. " + discountAmount + "\n" +
                                    "Final Price: Rs. " + finalPrice, 
                                    "Discount Calculation Success", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An unexpected error occurred while calculating discount: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // REWARD BUTTON ACTION LISTENER
        rewardButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to calculate reward points", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId;
                        try {
                            visitorId = Integer.parseInt(idText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                                "Invalid Visitor ID", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            double rewardPoints = foundVisitor.calculateRewardPoint();

                            if (rewardPoints == 0.0) {
                                JOptionPane.showMessageDialog(null, 
                                    "No reward points to calculate!\nReason: No product has been purchased yet.", 
                                    "Reward Points Calculation", JOptionPane.WARNING_MESSAGE);
                            } else {
                                String visitorType = foundVisitor instanceof StandardVisitor ? "Standard" : "Elite";
                                double pointsPerRupee = foundVisitor instanceof StandardVisitor ? 5 : 10;

                                JOptionPane.showMessageDialog(null, 
                                    "Reward Points Calculated Successfully!\n\n" +
                                    "Visitor ID: " + visitorId + "\n" +
                                    "Visitor Name: " + foundVisitor.getFullName() + "\n" +
                                    "Visitor Type: " + visitorType + "\n" +
                                    "Artwork: " + foundVisitor.getArtworkName() + "\n" +
                                    "Final Price Paid: Rs. " + foundVisitor.getFinalPrice() + "\n" +
                                    "Points Rate: " + pointsPerRupee + " points per rupee\n" +
                                    "Total Reward Points: " + rewardPoints, 
                                    "Reward Points Calculation Success", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An unexpected error occurred while calculating reward points: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });    

        // ASSIGN PERSONAL ART ADVISOR BUTTON ACTION LISTENER
        assignPersonalAdvisorButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to assign personal art advisor", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId;
                        try {
                            visitorId = Integer.parseInt(idText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                                "Invalid Visitor ID", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            // Check if the visitor is an EliteVisitor using instanceof
                            if (foundVisitor instanceof EliteVisitor) {
                                // Cast the ArtGalleryVisitor object to EliteVisitor
                                EliteVisitor eliteVisitor = (EliteVisitor) foundVisitor;

                                // Call the assignPersonalArtAdvisor() method
                                boolean advisorAssigned = eliteVisitor.assignPersonalArtAdvisor();

                                if (advisorAssigned) {
                                    // Also check for exclusive event access
                                    boolean eventAccess = eliteVisitor.exclusiveEventAccess();

                                    JOptionPane.showMessageDialog(null, 
                                        "Personal Art Advisor Assignment Successful!\n\n" +
                                        "Visitor ID: " + visitorId + "\n" +
                                        "Visitor Name: " + foundVisitor.getFullName() + "\n" +
                                        "Visitor Type: Elite\n" +
                                        "Current Reward Points: " + foundVisitor.getRewardPoints() + "\n" +
                                        "Personal Art Advisor: Assigned\n" +
                                        "Exclusive Event Access: " + (eventAccess ? "Granted" : "Not Granted") + "\n\n" +
                                        "Congratulations! You now have access to personalized art recommendations and expert guidance.", 
                                        "Advisor Assignment Success", JOptionPane.INFORMATION_MESSAGE);
                                } else {
                                    JOptionPane.showMessageDialog(null, 
                                        "Personal Art Advisor Assignment Failed!\n\n" +
                                        "Visitor ID: " + visitorId + "\n" +
                                        "Visitor Name: " + foundVisitor.getFullName() + "\n" +
                                        "Visitor Type: Elite\n" +
                                        "Current Reward Points: " + foundVisitor.getRewardPoints() + "\n" +
                                        "Required Points: 5000+\n\n" +
                                        "You need more than 5000 reward points to qualify for a personal art advisor.\n" +
                                        "Continue making purchases to earn more reward points!", 
                                        "Insufficient Reward Points", JOptionPane.WARNING_MESSAGE);
                                }
                            } else {
                                // Visitor is not an EliteVisitor (probably StandardVisitor)
                                String visitorType = foundVisitor instanceof StandardVisitor ? "Standard" : "Unknown";
                                JOptionPane.showMessageDialog(null, 
                                    "Personal Art Advisor service is only available for Elite Visitors.\n\n" +
                                    "Visitor ID: " + visitorId + "\n" +
                                    "Visitor Name: " + foundVisitor.getFullName() + "\n" +
                                    "Current Visitor Type: " + visitorType + "\n\n" +
                                    "Please upgrade to Elite membership to access premium services like personal art advisors.", 
                                    "Service Not Available", JOptionPane.WARNING_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An unexpected error occurred while assigning personal art advisor: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });    
        // CANCEL PRODUCT BUTTON ACTION LISTENER
        cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();
                        String artworkName = artworkNameField.getText().trim();
                        String cancellationReason = cancellationReasonField.getText().trim();

                        // Validate required fields
                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (artworkName.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter an Artwork Name", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (cancellationReason.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Cancellation Reason", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId = Integer.parseInt(idText);

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            String result = foundVisitor.cancelProduct(artworkName, cancellationReason);
                            JOptionPane.showMessageDialog(null, result, 
                                "Cancellation Result", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                            "Number Format Error", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An error occurred while processing cancellation: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // GENERATE BILL BUTTON ACTION LISTENER
        generateBillButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String idText = visitorIdField.getText().trim();

                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID to generate bill", 
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int visitorId;
                        try {
                            visitorId = Integer.parseInt(idText);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID", 
                                "Invalid Visitor ID", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        ArtGalleryVisitor foundVisitor = null;

                        // Search for visitor in the ArrayList
                        for (ArtGalleryVisitor visitor : visitorList) {
                            if (visitor.getVisitorId() == visitorId) {
                                foundVisitor = visitor;
                                break;
                            }
                        }

                        if (foundVisitor != null) {
                            if (foundVisitor.getIsBought()) {
                                // Ensure discount is calculated before generating bill
                                foundVisitor.calculateDiscount();

                                // Generate bill content
                                StringBuilder bill = new StringBuilder();
                                bill.append("==========================================\n");
                                bill.append("           ART GALLERY BILL\n");
                                bill.append("==========================================\n");
                                bill.append("Visitor ID: ").append(foundVisitor.getVisitorId()).append("\n");
                                bill.append("Visitor Name: ").append(foundVisitor.getFullName()).append("\n");
                                bill.append("Ticket Type: ").append(foundVisitor.getTicketType()).append("\n");
                                bill.append("------------------------------------------\n");
                                bill.append("Artwork Name: ").append(foundVisitor.getArtworkName()).append("\n");
                                bill.append("Artwork Price: Rs. ").append(String.format("%.2f", foundVisitor.getArtworkPrice())).append("\n");
                                bill.append("Discount Amount: Rs. ").append(String.format("%.2f", foundVisitor.getDiscountAmount())).append("\n");
                                bill.append("Final Price: Rs. ").append(String.format("%.2f", foundVisitor.getFinalPrice())).append("\n");
                                bill.append("------------------------------------------\n");
                                bill.append("Thank you for visiting our Art Gallery!\n");
                                bill.append("==========================================\n");

                                String billContent = bill.toString();

                                // Display bill in a dialog with scroll pane
                                JTextArea textArea = new JTextArea(billContent);
                                textArea.setEditable(false);
                                textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

                                JScrollPane scrollPane = new JScrollPane(textArea);
                                scrollPane.setPreferredSize(new Dimension(450, 350));

                                JOptionPane.showMessageDialog(null, scrollPane, "Generated Bill", JOptionPane.INFORMATION_MESSAGE);

                                // Save bill to file
                                try {
                                    String filename = "Bill_Visitor_" + visitorId + ".txt";
                                    java.io.FileWriter writer = new java.io.FileWriter(filename);
                                    writer.write(billContent);
                                    writer.close();

                                    JOptionPane.showMessageDialog(null, 
                                        "Bill generated and saved successfully!\nFile saved as: " + filename, 
                                        "Bill Generation Success", JOptionPane.INFORMATION_MESSAGE);

                                } catch (java.io.IOException ex) {
                                    JOptionPane.showMessageDialog(null, 
                                        "Bill displayed successfully, but error saving to file: " + ex.getMessage(), 
                                        "File Save Error", JOptionPane.WARNING_MESSAGE);
                                }

                            } else {
                                JOptionPane.showMessageDialog(null, 
                                    "No purchase made by this visitor to generate bill.\nVisitor ID: " + visitorId + 
                                    "\nVisitor Name: " + foundVisitor.getFullName(), 
                                    "No Purchase Found", JOptionPane.WARNING_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor with ID " + visitorId + " not found!", 
                                "Visitor Not Found", JOptionPane.WARNING_MESSAGE);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, 
                            "An unexpected error occurred while generating bill: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        // SAVE BUTTON ACTION LISTENER - Add this to your main method where other button listeners are defined
        saveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        // Import required for file operations
                        java.io.FileWriter writer = new java.io.FileWriter("VisitorDetails.txt");

                        // Write header
                        writer.write("===================================================================================================================================================================================================================================================================\n");
                        writer.write("                                               ART GALLERY VISITOR RECORDS\n");
                        writer.write("===================================================================================================================================================================================================================================================================\n");
                        writer.write(String.format("%-5s %-15s %-10s %-15s %-20s %-12s %-10s %-12s %-10s %-15s %-10s %-15s %-15s\n",
                                "ID", "Name", "Gender", "Phone", "Registration Date", "Ticket Type", "Price", "Visit Count", "Active", "Reward Points", "Bought", "Artwork", "Final Price"));
                        writer.write("===================================================================================================================================================================================================================================================================\n");

                        // Write visitor data
                        for (ArtGalleryVisitor visitor : visitorList) {
                            writer.write(String.format("%-5d %-15s %-10s %-15s %-20s %-12s %-10.2f %-12d %-10s %-15.2f %-10s %-15s %-15.2f\n",
                                    visitor.getVisitorId(),
                                    visitor.getFullName().length() > 15 ? visitor.getFullName().substring(0, 12) + "..." : visitor.getFullName(),
                                    visitor.getGender(),
                                    visitor.getContactNumber(),
                                    visitor.getRegistrationDate(),
                                    visitor.getTicketType(),
                                    visitor.getTicketCost(),
                                    visitor.getVisitCount(),
                                    visitor.getIsActive() ? "Yes" : "No",
                                    visitor.getRewardPoints(),
                                    visitor.getIsBought() ? "Yes" : "No",
                                    visitor.getArtworkName() != null ? (visitor.getArtworkName().length() > 15 ? visitor.getArtworkName().substring(0, 12) + "..." : visitor.getArtworkName()) : "None",
                                    visitor.getFinalPrice()
                                ));
                        }

                        writer.write("===================================================================================================================================================================================================================================================================\n");
                        writer.write("Total Visitors: " + visitorList.size() + "\n");
                        writer.close();

                        JOptionPane.showMessageDialog(null, "Visitor details saved to VisitorDetails.txt successfully!", "File Saved", JOptionPane.INFORMATION_MESSAGE);
                    } catch (java.io.IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error saving to file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "An unexpected error occurred while saving: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

        readButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                    try {
                        File file = new File("VisitorDetails.txt");
                        if (!file.exists()) {
                            JOptionPane.showMessageDialog(null, "VisitorDetails.txt file not found. Please save visitor data first.", "File Not Found", JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                        
                        StringBuilder content = new StringBuilder();
                        BufferedReader reader = new BufferedReader(new FileReader(file));
                        String line;
                        
                        while ((line = reader.readLine()) != null) {
                            content.append(line).append("\n");
                        }
                        reader.close();
                        
                        // Display file content in a new window
                        JFrame fileFrame = new JFrame("Visitor Records from File");
                        JTextArea textArea = new JTextArea(content.toString());
                        textArea.setEditable(false);
                        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
                        
                        JScrollPane scrollPane = new JScrollPane(textArea);
                        fileFrame.add(scrollPane);
                        fileFrame.setSize(1000, 600);
                        fileFrame.setLocationRelativeTo(null);
                        fileFrame.setVisible(true);
                        
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error reading from file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
            
            isEligibleForDiscountUpgradeButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                    try {
                        String visitorIdStr = visitorIdField.getText();
                        if (visitorIdStr.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please enter a Visitor ID.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        
                        int visitorId = Integer.parseInt(visitorIdStr);
                        
                        ArtGalleryVisitor visitor = null;
                        for (ArtGalleryVisitor v : visitorList) {
                            if (v.getVisitorId() == visitorId) {
                                visitor = v;
                                break;
                            }
                        }
                        
                        if (visitor != null) {
                            if (visitor instanceof StandardVisitor) {
                                StandardVisitor standardVisitor = (StandardVisitor) visitor;
                                boolean upgraded = standardVisitor.checkDiscountUpgrade();
                                if (upgraded) {
                                    JOptionPane.showMessageDialog(null, "Congratulations! You are eligible for discount upgrade (15%).", "Upgrade Available", JOptionPane.INFORMATION_MESSAGE);
                                } else {
                                    JOptionPane.showMessageDialog(null, "You need " + (standardVisitor.getVisitLimit() - visitor.getVisitCount() )+ " more visits for upgrade.","Warning", JOptionPane.INFORMATION_MESSAGE);
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "This service is only available for Standard Visitors.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Visitor ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid numeric Visitor ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        frame.add(panel);
        frame.setSize(950, 600);  
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Method to create and show visitor details in a new window
    private static void showVisitorDetailsWindow(ArtGalleryVisitor visitor) {
        try {
            // Create new window for visitor details
            JFrame detailsFrame = new JFrame("Visitor Details - ID: " + visitor.getVisitorId());
            detailsFrame.setSize(600, 500);
            detailsFrame.setLocationRelativeTo(null);
            detailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Create panel for the new window
            JPanel detailsPanel = new JPanel();
            detailsPanel.setLayout(new BorderLayout());
            detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            detailsPanel.setBackground(new Color(240, 248, 255));

            // Create text area for visitor details
            JTextArea detailsArea = new JTextArea();
            detailsArea.setEditable(false);
            detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            detailsArea.setBackground(Color.WHITE);
            detailsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Build the visitor details text
            StringBuilder displayText = new StringBuilder();
            displayText.append("═══════════════════════════════════════════════\n");
            displayText.append("                VISITOR DETAILS                \n");
            displayText.append("═══════════════════════════════════════════════\n\n");

            displayText.append("Visitor ID:          ").append(visitor.getVisitorId()).append("\n");
            displayText.append("Full Name:           ").append(visitor.getFullName()).append("\n");
            displayText.append("Gender:              ").append(visitor.getGender()).append("\n");
            displayText.append("Contact Number:      ").append(visitor.getContactNumber()).append("\n");
            displayText.append("Registration Date:   ").append(visitor.getRegistrationDate()).append("\n");
            displayText.append("Ticket Type:         ").append(visitor.getTicketType()).append("\n");
            displayText.append("Ticket Cost:         Rs. ").append(visitor.getTicketCost()).append("\n");
            displayText.append("Visit Count:         ").append(visitor.getVisitCount()).append("\n");
            displayText.append("Reward Points:       ").append(visitor.getRewardPoints()).append("\n");
            displayText.append("Is Active:           ").append(visitor.getIsActive() ? "Yes" : "No").append("\n");
            displayText.append("Is Bought:           ").append(visitor.getIsBought() ? "Yes" : "No").append("\n");

            // Show purchase details if visitor has bought something
            if (visitor.getIsBought()) {
                displayText.append("\n");
                displayText.append("───────────── PURCHASE DETAILS ─────────────\n");
                displayText.append("Artwork Name:        ").append(visitor.getArtworkName()).append("\n");
                displayText.append("Artwork Price:       Rs. ").append(visitor.getArtworkPrice()).append("\n");
                displayText.append("Discount Amount:     Rs. ").append(visitor.getDiscountAmount()).append("\n");
                displayText.append("Final Price:         Rs. ").append(visitor.getFinalPrice()).append("\n");
            }

            // Add specific details based on visitor type
            if (visitor instanceof StandardVisitor) {
                StandardVisitor stdVisitor = (StandardVisitor) visitor;
                displayText.append("\n");
                displayText.append("───────── STANDARD VISITOR DETAILS ─────────\n");
                displayText.append("Eligible for Discount Upgrade: ").append(stdVisitor.getIsEligibleForDiscountUpgrade() ? "Yes" : "No").append("\n");
                displayText.append("Visit Limit for Upgrade:       ").append(stdVisitor.getVisitLimit()).append("\n");
                displayText.append("Current Discount Percent:      ").append((stdVisitor.getDiscountPercent() * 100)).append("%\n");
            } else if (visitor instanceof EliteVisitor) {
                EliteVisitor eliteVisitor = (EliteVisitor) visitor;
                displayText.append("\n");
                displayText.append("─────────── ELITE VISITOR DETAILS ───────────\n");
                displayText.append("Assigned Personal Art Advisor: ").append(eliteVisitor.isAssignedPersonalArtAdvisor() ? "Yes" : "No").append("\n");
                displayText.append("Exclusive Event Access:        ").append(eliteVisitor.isExclusiveEventAccess() ? "Yes" : "No").append("\n");
            }

            displayText.append("\n═══════════════════════════════════════════════\n");

            detailsArea.setText(displayText.toString());

            // Add scroll pane
            JScrollPane scrollPane = new JScrollPane(detailsArea);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

            // Add components to panel
            detailsPanel.add(scrollPane, BorderLayout.CENTER);

            // Create close button
            JButton closeButton = new JButton("Close");
            closeButton.setPreferredSize(new Dimension(100, 30));
            closeButton.addActionListener(e -> detailsFrame.dispose());

            JPanel buttonPanel = new JPanel(new FlowLayout());
            buttonPanel.add(closeButton);
            buttonPanel.setBackground(new Color(240, 248, 255));

            detailsPanel.add(buttonPanel, BorderLayout.SOUTH);

            // Add panel to frame and show
            detailsFrame.add(detailsPanel);
            detailsFrame.setVisible(true);

            JOptionPane.showMessageDialog(null, "Visitor details window opened successfully!", 
                "Display Complete", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while creating details window: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}