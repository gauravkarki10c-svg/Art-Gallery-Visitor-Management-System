/**
 * Extended child class
 */
// StandardVisitor class extending ArtGalleryVisitor
public class StandardVisitor extends ArtGalleryVisitor
    // Declaring varibales with appropiate access modifiers
{   private boolean isEligibleForDiscountUpgrade;
    private final int visitLimit;
    private float discountPercent;
    //Constructor of this class
    public StandardVisitor(int visitorId, String fullName, String gender, String contactNumber, String registrationDate, double ticketCost, String ticketType)
    {
        super(visitorId, fullName, gender, contactNumber, registrationDate, ticketCost, ticketType);
        this.visitLimit = 5;
        this.discountPercent = 0.10f;
        this.isEligibleForDiscountUpgrade = false;
    }
    //Below are three getter methods
    public int getVisitLimit()
    {
        return visitLimit;
    }
    
    public float getDiscountPercent()
    {
        return discountPercent;
    }
    
    public boolean getIsEligibleForDiscountUpgrade()
    {
        return isEligibleForDiscountUpgrade;
    }
    // Method to check and update discount upgrade eligibility
    public boolean checkDiscountUpgrade()
    {
        if (visitCount >= visitLimit)
        {
            isEligibleForDiscountUpgrade = true;
            discountPercent = 0.15f;
        }
        
        return isEligibleForDiscountUpgrade;
    }   
    //Overrided method for purchase of products in this class
    @Override
    public String buyProduct(String artworkName, double artworkPrice) 
    {
        if (!isActive) 
        {
                return "Please log in before making a purchase.";
        }

        if (this.artworkName == null || !this.artworkName.equals(artworkName)) 
        {
            this.artworkName = artworkName;
            this.artworkPrice = artworkPrice;
            isBought = true;
            buyCount++;
            return "Purchase is successful for " + artworkName + artworkPrice;
        } 
        else 
        {
        return "You have already purchased this artwork.";
        }
    
    }
    //Overrided method to calculate discount for this class
    @Override
    public double calculateDiscount()
    {
        if (!isBought)
        {
            return 0.0;
        }
        checkDiscountUpgrade();
        discountAmount = artworkPrice * discountPercent;
        finalPrice = artworkPrice - discountAmount;
        return discountAmount;
    }
    //Overrided method to calculate reward point for this class
    @Override
    public double calculateRewardPoint()
    {
        if (!isBought)
        {
            return 0.0;
        }
        rewardPoints += finalPrice * 5;
        return rewardPoints;
    }
    //Overrided method to generate bill for this class
    @Override
    public void generateBill()
    {
        if (!isBought)
        {
            System.out.println("Purchase has not been made so we cannot generate a bill.");
            return;
        }
        
        System.out.println("Your bill details are below: ");
        System.out.println("Visitor ID: " + visitorId);
        System.out.println("Visitor Name: " + fullName);
        System.out.println("Artwork Name: " + artworkName);
        System.out.println("Artwork Price: " + artworkPrice);
        System.out.println("Discount Amount: " + discountAmount);
        System.out.println("Total Price: " + finalPrice);
    }
    //Overrided method to terminate visitor for this class
    private void terminateVisitor()
    {
        isActive = false;
        isEligibleForDiscountUpgrade = false;
        visitCount = 0;
        cancelCount = 0;
        rewardPoints = 0;
    }
    //Overrided method to cancel product for this class
    @Override
    public String cancelProduct(String artworkName, String cancellationReason)
    {
        if (cancelCount >= cancelLimit)
        {
            terminateVisitor();
            return "Dear customer, your cancellation limit has been reached. Visitor account has been terminated.";
        }
        
        if (buyCount == 0)
        {
            return "There is no product to cancel.";
        }
        
        if (this.artworkName != null && this.artworkName.equals(artworkName))
        {
            this.artworkName = null;
            isBought = false;
            refundableAmount = artworkPrice - (artworkPrice * 0.10);
            rewardPoints -= finalPrice * 5;
            cancelCount++;
            buyCount--;
            this.cancellationReason = cancellationReason;
            return "Cancellation is successful. Refund amount: " + refundableAmount;
        }
        
        else
        {
            return " The Artwork name does not match the purchased item.";
        }
    }
    //Overrided method to disaply the visitor details for this class
    @Override
    public void display()
    {
        super.display();
        System.out.println("StandardVisitor Details: ");
        System.out.println("You are eligible for discount upgrade: " + isEligibleForDiscountUpgrade);
        System.out.println("Visit Limit for Upgrade: " + visitLimit);
        System.out.println("Current Discount Percent: " + discountPercent);
    }
    
}