/**
 * Extended child class
 */
// EliteVisitor class extending ArtGalleryVisitor
public class EliteVisitor extends ArtGalleryVisitor
    // Declaring varibales with appropiate access modifiers
{   private boolean assignedPersonalArtAdvisor;
    private boolean exclusiveEventAccess;
    //Constructor of this class
    public EliteVisitor(int visitorId, String fullName, String gender, String contactNumber, String registrationDate, double ticketCost, String ticketType)
    {
        super(visitorId, fullName, gender, contactNumber, registrationDate, ticketCost, ticketType);
        this.assignedPersonalArtAdvisor = false;
        this.exclusiveEventAccess = false;
    }
    // Getter method to check if personal art advisor is assigned to the visitor
    public boolean isAssignedPersonalArtAdvisor()
    {
        return assignedPersonalArtAdvisor;
    }
    // Getter method to check if the visitor has access to exclusive events
        public boolean isExclusiveEventAccess()
    {
        return exclusiveEventAccess;
    }
    // Method to assign personal art advisor to the visitor based on reward points 
    public boolean assignPersonalArtAdvisor()
    {
        if (rewardPoints > 5000)
        {
            assignedPersonalArtAdvisor = true;
        }
        
        return assignedPersonalArtAdvisor;
    }
    // Method to give access for exclusive event to the visitor based on advisor assignment
    public boolean exclusiveEventAccess()
    {
        if (assignedPersonalArtAdvisor)
        {
            exclusiveEventAccess = true;
        }
        
        return exclusiveEventAccess;
    }
    //Overrided method for purchase of products in this class
    @Override
    public String buyProduct(String artworkName, double artworkPrice)
    {
        if (!isActive)
        {
            return "Please log in first before making a purchase.";
        }
        
        if (this.artworkName == null || !this.artworkName.equals(artworkName))
        {
            this.artworkName = artworkName;
            this.artworkPrice = artworkPrice;
            isBought = true;
            buyCount++;
            
            calculateDiscount();
            return "Purchase successful: " + artworkName + " for " + finalPrice +" Discount Applied: " + discountAmount + "";
        }
        
        else
        {
            return "You have already purchased this artwork.";
        }
    }
    //Overrided method to calculate discount for this class
    @Override
    public double calculateDiscount()
    {
        if (!isBought)
        {
            return 0.0;
        }
        
        discountAmount = artworkPrice * 0.40;
        finalPrice = artworkPrice - discountAmount;
        return discountAmount;
    }
    //Overrided method to calculate reward point for this class
    @Override
    public double calculateRewardPoint()
    {
        if (!isBought)
        {
            return 0.0;
        }
        
        rewardPoints += finalPrice * 10;
        return rewardPoints;
    }
    //Overrided method to generate bill for this class
    @Override
    public void generateBill()
    {
        if (!isBought)
        {
            System.out.println("Purchase has not been made so we cannot generate a bill.");
            return;
        }
        
        System.out.println("Your bill details are below: ");
        System.out.println("Visitor ID: " + visitorId);
        System.out.println("Visitor Name: " + fullName);
        System.out.println("Artwork Name: " + artworkName);
        System.out.println("Artwork Price: " + artworkPrice);
        System.out.println("Discount Amount: " + discountAmount);
        System.out.println("Total Price: " + finalPrice);
    }
    //Overrided method to terminate visitor for this class
    private void terminateVisitor()
    {
        isActive = false;
        assignedPersonalArtAdvisor = false;
        exclusiveEventAccess = false;
        visitCount = 0;
        cancelCount = 0;
        rewardPoints = 0;
    }
    //Overrided method to cancel product for this class
    @Override
    public String cancelProduct(String artworkName, String cancellationReason)
    {
        if (cancelCount >= 3)
        {
            terminateVisitor();
            return " Dear customer cancellation limit has reached. Visitor account has been terminated.";
        }
        
        if (buyCount == 0)
        {
            return "No product has been purchased to cancel.";
        }
        
        if (this.artworkName != null && this.artworkName.equals(artworkName))
        {
            isBought = false;
            this.artworkName = null;
            refundableAmount = artworkPrice - (artworkPrice * 0.05);
            rewardPoints -= finalPrice * 10;
            cancelCount++;
            buyCount--;
            this.cancellationReason = cancellationReason;
            return "Cancellation successful. Refundable amount: " + refundableAmount;
        }
        
        else
        {
            return "Artwork name incorrect. Cancellation failed.";
        }
    }
    //Overrided method to disaply the visitor details for this class
    @Override
    public void display()
    {
        super.display();
        System.out.println("EliteVisitor Details: ");
        System.out.println("Assigned Personal Art Advisor: " + assignedPersonalArtAdvisor);
        System.out.println("Exclusive Event Access: " + exclusiveEventAccess);
    }
    
}

